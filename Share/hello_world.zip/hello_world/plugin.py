﻿from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget

from core.plugin_base import Plugin


class HelloWorldPlugin(Plugin):
    id = "hello_world"
    title = "Hello World (пример)"
    version = "0.1.0"

    def activate(self, api):
        self.api = api

        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setAlignment(Qt.AlignCenter)

        label = QLabel("Привет из плагина Hello World! 👋")
        label.setStyleSheet("font-size: 20px;")
        label.setAlignment(Qt.AlignCenter)

        btn = QPushButton("Показать сообщение")
        btn.clicked.connect(
            lambda: api.show_message("Кнопка из плагина нажата!", "success")
        )

        lay.addWidget(label)
        lay.addWidget(btn)

        api.add_tab(w, "Hello World")
        api.add_menu_action(
            "tools", "Hello World: поздороваться",
            lambda: api.show_message("Привет от плагина!", "success"),
        )
        api.add_toolbar_action(
            "👋", lambda: api.show_message("Тулбар плагина", "info")
        )

        count = api.get_setting("activations", 0) + 1
        api.set_setting("activations", count)